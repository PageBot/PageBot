# -*- coding: UTF-8 -*-
# -----------------------------------------------------------------------------
#     Contributed by Erik van Blokland and Jonathan Hoefler#     Original from filibuster.#
#     P A G E B O T
#
#     Licensed under MIT conditions
#     Made for usage in DrawBot, www.drawbot.com
# -----------------------------------------------------------------------------
#
"""
        history
        Legal content, should offer a lot of fun to write, this is not used so far
--------------------------------------------------------------------
3.0.0    - split all the content into babycontents
evb        - note: only one dictionary named 'content' allowed per module
        this limitation is to speed up loading

"""

__version__ = '3.0.0'
__author__ = "someone"

content = {

    'classified_headline':(
            'Commercial Rentals', 'Business Opportunities', 'Bed &amp; Breakfast', 'Year Round Rentals', 
            'Winter Rentals', 'Apartments/Rooms', 'Vacation/Summer Rentals', 'Off-Island Rentals', 'Rentals Wanted', 
            'Articles For Sale', 'Yard Sales', 'Wanted', 'Music &amp; Arts', 'Pets &amp; Livestock', 'Help Wanted', 
            'Child Care Wanted', 'CareGiving Offered', 'Instruction', 'Services', 'Home Services', 
            'Landscaping &amp; Gardening', 'Heating Supplies &amp; Service', 'Announcements', 'Public Notices', 
            'Lost &amp; Found', 'Legal Notices <#city#>', 'Bargain Box'),
    }
