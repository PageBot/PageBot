# -*- coding: UTF-8 -*-
# -*- coding: UTF-8 -*-
# -----------------------------------------------------------------------------
#     Contributed by Erik van Blokland and Jonathan Hoefler#     Original from filibuster.#
#     P A G E B O T
#
#     Licensed under MIT conditions
#     Made for usage in DrawBot, www.drawbot.com
# -----------------------------------------------------------------------------
#
'''
Created on May 25, 2011

@author: petr
'''

__version__ = '3.0.1'
__author__ = "someone"


# ------------------------------------------------------
#    xierpa stuff
#
content = { }
